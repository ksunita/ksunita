export const environment = {
  production: true,
  loginUrl : 'http://ec2-3-110-45-29.ap-south-1.compute.amazonaws.com:8081/login',
  postTweetMsg : 'http://ec2-3-110-45-29.ap-south-1.compute.amazonaws.com:8081/tweet/add',
  getAllTweets: 'http://ec2-3-110-45-29.ap-south-1.compute.amazonaws.com:8081/tweet/all',
  getUser: 'http://ec2-3-110-45-29.ap-south-1.compute.amazonaws.com:8081/user',
  likeTweetUrl : 'http://ec2-3-110-45-29.ap-south-1.compute.amazonaws.com:8081/tweet/like',
  updateTweetUrl : 'http://ec2-3-110-45-29.ap-south-1.compute.amazonaws.com:8081/tweet/update',
  adduser : 'http://ec2-3-110-45-29.ap-south-1.compute.amazonaws.com:8081/user/save',
  resetPasswordUrl : 'http://ec2-3-110-45-29.ap-south-1.compute.amazonaws.com:8081/user/forgotPassword',
  deleteTweetUrl : 'http://ec2-3-110-45-29.ap-south-1.compute.amazonaws.com:8081/tweet/delete',
  replyTweetUrl : 'http://ec2-3-110-45-29.ap-south-1.compute.amazonaws.com:8081/tweet/reply',
  userTweetsUrl : 'http://ec2-3-110-45-29.ap-south-1.compute.amazonaws.com:8081/tweet/user'

};
