export class Request {
    requestBody : any;
    constructor (requestBody : any){
        this.requestBody = requestBody;
    }  
}