export const CurrentUser = {
    contactnumber: "7661828239",
    dob: "OCT/05/1998",
    email: "neeraja.uppalapati@gmail.com",
    firstName: "neeraja",
    gender: "female",
    id: "62032d53f83131322187fd3b",
    lastname: "Uppalapati",
    password: "$2a$10$lG6Me6krB/vCoobxMdjN1.TjsOlsv1g6eelAfnAl9Y2s//HuqCC1."
}
export const allTweets = [{email: "neeraja.uppalapati@gmail.com",id: "628e1354ef68492b2db3b2ff",like: 0,replyTweet: [],Text: "",time: "06/09/2022 5:39:45",tweetMsg: "kkkk"},
{email: "neeraja.uppalapati@gmail.com",id: "628f0406a1b5ca7eeeeffeab",like: 6,replyTweet: [],tagText: "empty tags",time: "05/29/2022 12:57:17",
tweetMsg: "from cloud"
}]
export const postTweetSuccessfullResponse = {
    email: "neeraja.uppalapati@gmail.com",
    id: "62a1ea9052ff175ac9844f0c",
    like: 0,
    replyTweet: [],
    tagText: "",
    time: "06/09/2022 6:11:52",
    tweetMsg: "heyi"
}