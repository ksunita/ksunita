import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserLoginComponent } from './tweet-app-component/user-login/user-login.component';
import { UserRegisterComponent } from './tweet-app-component/user-register/user-register.component';
import { HomeComponentComponent } from './tweet-app-component/home-component/home-component.component';
import { EditTweetComponent } from './tweet-app-component/edit-tweet/edit-tweet.component';
import { NavbarComponent } from './tweet-app-component/navbar/navbar.component';
import { ReplyTweetComponent } from './tweet-app-component/reply-tweet/reply-tweet.component';
import { ResetPasswordComponent } from './tweet-app-component/reset-password/reset-password.component';
import { TweetMsgComponent } from './tweet-app-component/tweet-msg/tweet-msg.component';
import { UserTweetsComponent } from './tweet-app-component/user-tweets/user-tweets.component';
import { DatePipe } from '@angular/common';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { ModalModule } from 'ngb-modal';
import { AuthGuard } from './auth/auth.gard';
import { TokenInterceptor } from './auth/token.interceptor';
import { BackgroundImageComponent } from './background-image/background-image.component';
@NgModule({
    declarations: [
        AppComponent,
        UserLoginComponent,
        UserRegisterComponent,
        HomeComponentComponent,
        EditTweetComponent,
        NavbarComponent,
        ReplyTweetComponent,
        ResetPasswordComponent,
        TweetMsgComponent,
        UserTweetsComponent,
        BackgroundImageComponent
    ],
    imports: [
        HttpClientModule,
        ReactiveFormsModule,
        BrowserModule,
        AppRoutingModule,
        // NgbModal.forRoot()
        NgbModule,
        ModalModule
    ],
    providers: [DatePipe,
        {
            provide: HTTP_INTERCEPTORS,
            useClass: TokenInterceptor,
            multi: true
        }, AuthGuard],
    bootstrap: [AppComponent]
})
export class AppModule { }

