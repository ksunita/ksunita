import { Component, OnInit } from '@angular/core';
//import { ITS_JUST_ANGULAR } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserServiceService } from 'src/app/Services/user-service.service';
import { User } from '../home-component/model/User';

@Component({
  selector: 'app-user-register',
  templateUrl: './user-register.component.html',
  styleUrls: ['./user-register.component.scss']
})
export class UserRegisterComponent implements OnInit {

  usercpassword : String = '';
  userpassword : String = '';
  registrationForm = new UntypedFormGroup({
    firstname : new UntypedFormControl('', Validators.required),
    lastname : new UntypedFormControl(''),
    gender : new UntypedFormControl('', Validators.required),
    dob : new UntypedFormControl('', [Validators.required, Validators.pattern('^[0-9]{2}-[0-9]{2}-[0-9]{4}$')]),
    email : new UntypedFormControl('', [Validators.required, Validators.pattern('^(?=[a-zA-Z0-9@._%+-]{6,100}$)[a-zA-Z0-9._%+-]{1,50}@(?:[a-zA-Z0-9-]{1,12}\\.){1,12}[a-zA-Z0-9\\.-]{2,4}$')]),
    password : new UntypedFormControl('', Validators.required),
    cpassword : new UntypedFormControl('', Validators.required),
    contactnumber : new UntypedFormControl('', [Validators.required, Validators.pattern('^[0-9]{10}$')])
  });
  cpassError: boolean = false;
  registrationFailed: boolean = false;
  msg: any;
  constructor(private userService : UserServiceService, private router : Router) { }

  ngOnInit(): void {
  }
  register(){
    this.registrationFailed = false;
        this.userpassword = this.registrationForm.controls.password.value;
        this.usercpassword = this.registrationForm.controls.cpassword.value;
        if(this.userpassword.localeCompare(this.usercpassword.toString()) == 0){
          console.log("registering new User" + " "+  this.registrationForm.controls.firstname.value);
          const request = new User(this.registrationForm.controls.firstname.value,
          this.registrationForm.controls.lastname.value,
          this.registrationForm.controls.gender.value,
          this.registrationForm.controls.dob.value,
          this.registrationForm.controls.email.value,
          this.userpassword,this.usercpassword
          );
          this.userService.adduser(request).subscribe(data => {
            console.log(data);
            if(data.StatusCode === "200"){
            this.router.navigate(['/login']);}
            else if (data.StatusCode === "11000"){
              this.registrationFailed = true;
              this.msg = data.Description;
            }
          });
        }
        else {
          this.cpassError = true;
        }
  }
}
