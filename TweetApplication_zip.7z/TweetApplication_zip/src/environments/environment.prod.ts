export const environment = {
  production: true,
  loginUrl : 'http://ec2-3-110-45-29.ap-south-1.compute.amazonaws.com:8081/login',
  postTweetMsg : 'http://ec2-3-110-45-29.ap-south-1.compute.amazonaws.com:8081/api/v1.0/tweets/tweet/add',
  getAllTweets: 'http://ec2-3-110-45-29.ap-south-1.compute.amazonaws.com:8081/api/v1.0/tweets/tweet/all',
  getUser: 'http://ec2-3-110-45-29.ap-south-1.compute.amazonaws.com:8081/api/v1.0/tweets/user/search',
  likeTweetUrl : 'http://ec2-3-110-45-29.ap-south-1.compute.amazonaws.com:8081/api/v1.0/tweets/tweet/user/like',
  updateTweetUrl : 'http://ec2-3-110-45-29.ap-south-1.compute.amazonaws.com:8081/api/v1.0/tweets/tweet/user/update',
  adduser : 'http://ec2-3-110-45-29.ap-south-1.compute.amazonaws.com:8081/api/v1.0/tweets/register',
  resetPasswordUrl : 'http://ec2-3-110-45-29.ap-south-1.compute.amazonaws.com:8081/api/v1.0/tweets/user/forgotPassword',
  deleteTweetUrl : 'http://ec2-3-110-45-29.ap-south-1.compute.amazonaws.com:8081/api/v1.0/tweets/tweet/user/delete',
  replyTweetUrl : 'http://ec2-3-110-45-29.ap-south-1.compute.amazonaws.com:8081//api/v1.0/tweets/tweet/user/reply',
  userTweetsUrl : 'http://ec2-3-110-45-29.ap-south-1.compute.amazonaws.com:8081/api/v1.0/tweets/tweet/user'
};
