package springdemoannotation.springdemoannotation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDemoAnnotationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringDemoAnnotationApplication.class, args);
	}

}
